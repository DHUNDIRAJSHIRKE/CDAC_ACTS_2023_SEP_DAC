package com.app.dao;

public interface PlayerDao {
      
}
